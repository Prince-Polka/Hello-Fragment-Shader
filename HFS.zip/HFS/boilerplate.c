#include "core/hfs.c"
void setup(){
  size(800,600);
}
void draw(){
  setPixel(canvas,mouseX,mouseY,0x00ff00ff); // paint green pixel at mouse
  // setPixel(PImage target, x, y, 0xRRGGBBAA)
}
void afterResize(){
  printf(
  "Window is now %d x %d pixels, and %lf seconds has passed. \n",
  width, height, seconds());

  for(int y=0;y<height;y++)
  for(int x=0;x<width;x++)
  canvas.pixels[y*width+x] = (y*255/height)<<24 |0xff;

  updatePixels(canvas);
}