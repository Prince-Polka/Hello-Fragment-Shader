#include "core/hfs.c"
void setup(){
  size(800,600);
}
void draw(){
  printf("%lf seconds \n",seconds());
}