/*
    TEXTURE GUIDE 
    https://open.gl/textures
*/
unsigned int Nimages = 0; // N < GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS
typedef struct PImage {
 unsigned int 
 width,
 height,
 texUnit,
 texture,
 *pixels;
} PImage;
PImage createImage(unsigned int w, unsigned int h){
 PImage ret;
 ret.width = w;
 ret.height = h;
 ret.texUnit = Nimages;
 ret.pixels = malloc(w*h * sizeof(unsigned int));
 glActiveTexture(0x84C0 + ret.texUnit);
 glGenTextures(1,&ret.texture);
 unsigned int mode = 0x84F5; // GL_TEXTURE_RECTANGLE
 glBindTexture(mode, ret.texture);
 glTexImage2D(mode, 0, 0x8D70, w, h, 0, 0x8D99, 0x8035, ret.pixels); 
 // 0x8D70 GL_RGBA32UI
 // 0x8D99 GL_RGBA_INTEGER
 // 0x8035 GL_UNSIGNED_INT_8_8_8_8           
 glTexParameteri(mode, 0x2800, 0x2601); //0x2601 linear 0x2609 nearest
 glTexParameteri(mode, 0x2801, 0x2601);
 glTexParameteri(mode, 0x2802, 0x812F); // 0x812F clamp
 glTexParameteri(mode, 0x2803, 0x812F);
 Nimages++;
 return ret;
}

void updatePixels(PImage in){
    glActiveTexture(0x84C0 + in.texUnit);
    // replace teximage with glTexStorage() ?
    // they don't load anything
    //glTexStorage2D(GLenum target​, GLsizei levels​, GLenum internalformat​ , GLsizei width​, GLsizei height​);
    //glTexStorage2D(0x84F5, 0, 0x8D8E, in.width, in.height); // 0x8D8E = GL_RGBA8I
    //glTextureStorage2D(in.texture, 0, 0x8D8E, in.width, in.height);
    glTexImage2D(0x84F5, 0, 0x8D70, in.width, in.height, 0, 0x8D99, 0x8035, in.pixels);
}

void setPixel(PImage target,unsigned int x, unsigned int y,unsigned int c){
    unsigned int pixelc[1];
    pixelc[0]=c;
    glActiveTexture(0x84C0 + target.texUnit);
    glTexSubImage2D(0x84F5,0,x,y,1,1,0x8D99, 0x8035,&pixelc);
}